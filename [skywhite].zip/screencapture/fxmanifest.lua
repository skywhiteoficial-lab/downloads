fx_version 'bodacious'

version '0.13.0-beta.5'

game "gta5"

node_version '22'

client_script "game/dist/client.js"
server_script "game/dist/server.js"

ui_page "game/nui/dist/index.html"
files {
    "game/nui/dist/index.html",
    "game/nui/dist/**/*",
}

provide 'screenshot-basic'

protocol 'http'

images_bps '8000000'
stream_bps '30000000'