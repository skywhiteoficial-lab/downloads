Config = {}

-- Hash fornecida pelo site (colocada pelo cliente)
Config.Licenca = "XXXX-XXXX-XXX"
