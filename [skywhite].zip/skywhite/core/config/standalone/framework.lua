-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- Instancia compartilhada do Kernel (definida em core/modules/lib/kernel.lua).
local Kernel = _G["SkywhiteKernel"]

-- ==========================================================================
-- ⚙️ ÁREA PERSONALIZÁVEL — FRAMEWORK PRÓPRIO
-- 🇧🇷 Aqui você pode modificar e adaptar sua framework conforme necessário.
--
-- 🇺🇸 CUSTOMIZABLE AREA — CUSTOM FRAMEWORK
-- 🇺🇸 Here you can modify and adapt your framework as needed.
-- ==========================================================================


--[[
    FrameworkPermissions.Add()
    Retorno esperado: true | false

    Use apenas se precisar de uma fonte de permissão adicional.
    ACE (add_ace/add_principal) já possui fallback automático.
]]


FrameworkPermissions.Add(function(source, permission)

    -- Kernel próprio:
    -- local ok, result = pcall(function()
    --     return exports["seu_framework"]:HasPermission(source, permission)
    -- end)
    -- if ok and result == true then
    --     return true
    -- end

    -- Permissões por license:
    -- local Admins = {
    --     ["license:xxxxxxxx"] = { "owner", "admin" }
    -- }
    --
    -- for _, identifier in ipairs(GetPlayerIdentifiers(source) or {}) do
    --     if identifier:find("^license:") then
    --         local groups = Admins[identifier]
    --         if groups then
    --             for _, group in ipairs(groups) do
    --                 if FrameworkPermissions.Normalize(group) == permission then
    --                     return true
    --                 end
    --             end
    --         end
    --     end
    -- end

    -- Banco de dados:
    -- local rows = exports.oxmysql:executeSync(
    --     "SELECT cargo FROM sua_tabela WHERE identifier = ?",
    --     { GetPlayerIdentifiers(source)[1] }
    -- )
    --
    -- if rows and rows[1] then
    --     return FrameworkPermissions.Normalize(rows[1].cargo) == permission
    -- end

    return false
end)

-- ==========================================================================
-- PROVIDER STANDALONE (hooks do skywhite)
-- --------------------------------------------------------------------------
-- Sem framework: o user_id e a license do jogador (sem o prefixo "license:").
-- O skywhite continua funcionando normalmente (ban, identidade por license,
-- eventos de spawn genericos + fallback de 15s no client).
-- ==========================================================================

local function getPlayerLicense(source)
    if not source or source == 0 then return nil end

    local id = nil
    if type(GetPlayerIdentifierByType) == "function" then
        id = GetPlayerIdentifierByType(source, "license2") or GetPlayerIdentifierByType(source, "license")
    end

    if not id and type(GetPlayerIdentifiers) == "function" then
        local ids = GetPlayerIdentifiers(source)
        if ids then
            for _, v in ipairs(ids) do
                if v:sub(1, 8) == "license:" then
                    id = v
                    break
                end
            end
        end
    end

    if not id then return nil end
    return (id:gsub("^license2?:", ""))
end

Kernel.register("standalone", {
    -- Sempre ativo (ultimo recurso da cadeia).
    isActive = function()
        return true
    end,

    -- user_id = license (string, sem prefixo)
    getUserId = getPlayerLicense,

    -- source a partir da license
    getUserSource = function(user_id)
        if type(GetPlayers) ~= "function" then return nil end
        user_id = tostring(user_id)

        for _, src in ipairs(GetPlayers()) do
            local id = getPlayerLicense(src)
            if id and tostring(id) == user_id then
                return tonumber(src)
            end
        end

        return nil
    end,

    -- Sem identidade propria (nome cai no GetPlayerName / resolveDisplayName).
    getIdentity = function()
        return nil
    end,

    -- Resolucao offline: user_id = license (sem prefixo, mesmo formato do
    -- getUserId). Nao ha banco proprio; apenas devolve o que recebeu.
    resolveUserIdFromIds = function(license, steam)
        if license then return license end
        return steam
    end,

    -- Resolucao offline reversa: monta a license a partir do user_id.
    getIdentifiersByUserId = function(user_id)
        if not user_id or user_id == "" then return nil end
        return { "license:" .. tostring(user_id) }
    end,

    -- Sem evento de spawn proprio (usa playerSpawned + fallback de 15s).
    spawnEvents = {},
})

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================
