-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- ==========================================================================
-- ADAPTER CLIENT STANDALONE
-- --------------------------------------------------------------------------
-- Sem framework, as notificacoes do skywhite ("skywhite:notify") caem no
-- chat (mesmo comportamento do fallback generico). Sinta-se livre para
-- trocar pela sua propria notificacao aqui.
-- ==========================================================================
KernelClient.register("standalone", function(kind, message, duration)
    TriggerEvent("chat:addMessage", -1, { args = { "[SKYWHITE]", tostring(message) } })
end)