-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- ==========================================================================
-- ADAPTER CLIENT QBCore
-- --------------------------------------------------------------------------
-- Traduz as notificacoes do skywhite ("skywhite:notify") para a notificacao
-- nativa do QBCore:
--   TriggerEvent("QBCore:Notify", mensagem, tipo, duracaoMilissegundos)
-- Mapeamento dos tipos do skywhite: negado -> error, sucesso -> success,
-- aviso -> warning, demais -> info.
-- ==========================================================================
local function mapQbType(kind)
    if kind == "negado" then return "error" end
    if kind == "sucesso" then return "success" end
    if kind == "aviso" then return "warning" end
    return "info"
end

KernelClient.register("qbcore", function(kind, message, duration)
    local ms = duration and (tonumber(duration) * 1000) or nil
    TriggerEvent("QBCore:Notify", tostring(message), mapQbType(kind), ms)
end)