-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- Instancia compartilhada do Kernel (definida em core/modules/lib/kernel.lua).
local Kernel = _G["SkywhiteKernel"]

local QBCore_object = nil

local function getQBCore()
    if not QBCore_object then
        local ok, result = pcall(function()
            return exports['qb-core']:GetCoreObject()
        end)
        if ok and result then
            QBCore_object = result
        end
    end
    return QBCore_object
end

-- ==========================================================================
-- PROVIDER QBCore (hooks do skywhite)
-- ==========================================================================
-- user_id = citizenid (string); identidade = PlayerData.charinfo (online) ou
-- players.charinfo (offline). Evento de spawn do client: QBCore:Client:OnPlayerLoaded.
-- ==========================================================================

-- Estrutura padrao de identidade usada pelo resto do resource.
local function buildIdentity(first, last)
    first = tostring(first or ""):gsub("^%s*(.-)%s*$", "%1")
    last = tostring(last or ""):gsub("^%s*(.-)%s*$", "%1")
    if first == "" and last == "" then return nil end
    return {
        name = first,
        firstname = last,
        lastname = last,
        sobrenome = last,
        name2 = last,
        nome = first,
    }
end

-- citizenid do jogador online.
local function getCitizenId(source)
    local QBCore = getQBCore()
    if not QBCore or type(QBCore.Functions) ~= "table" or type(QBCore.Functions.GetPlayer) ~= "function" then
        return nil
    end

    local ok, Player = pcall(QBCore.Functions.GetPlayer, source)
    if ok and Player and Player.PlayerData and Player.PlayerData.citizenid and Player.PlayerData.citizenid ~= "" then
        return Player.PlayerData.citizenid
    end

    return nil
end

-- Identidade online (charinfo do jogador conectado).
local function getOnlineIdentity(user_id)
    local QBCore = getQBCore()
    if not QBCore or type(QBCore.Functions) ~= "table" or type(QBCore.Functions.GetPlayer) ~= "function" then
        return nil
    end

    if type(GetPlayers) ~= "function" then return nil end

    for _, src in ipairs(GetPlayers()) do
        local ok, Player = pcall(QBCore.Functions.GetPlayer, src)
        if ok and Player and Player.PlayerData then
            local cid = Player.PlayerData.citizenid
            if cid and tostring(cid) == tostring(user_id) and Player.PlayerData.charinfo then
                local ci = Player.PlayerData.charinfo
                return buildIdentity(ci.firstname, ci.lastname)
            end
        end
    end

    return nil
end

-- Identidade offline (banco padrao do QBCore: players.charinfo).
local function getOfflineIdentity(user_id)
    if not user_id or user_id == "" or not exports or not exports.oxmysql then
        return nil
    end

    local okQ, rowsQ = pcall(function()
        return exports.oxmysql:executeSync("SELECT charinfo FROM players WHERE citizenid = ? LIMIT 1", { user_id })
    end)
    if okQ and type(rowsQ) == "table" and rowsQ[1] and rowsQ[1].charinfo then
        local okJ, ci = pcall(json.decode, tostring(rowsQ[1].charinfo))
        if okJ and type(ci) == "table" then
            local id = buildIdentity(ci.firstname, ci.lastname)
            if id then return id end
        end
    end

    return nil
end

Kernel.register("qbcore", {
    -- QBCore disponivel?
    isActive = function()
        return getQBCore() ~= nil
    end,

    -- user_id = citizenid (string)
    getUserId = getCitizenId,

    -- source a partir do citizenid
    getUserSource = function(user_id)
        if type(GetPlayers) ~= "function" then return nil end
        user_id = tostring(user_id)

        for _, src in ipairs(GetPlayers()) do
            local cid = getCitizenId(src)
            if cid and tostring(cid) == user_id then
                return tonumber(src)
            end
        end

        return nil
    end,

    -- Identidade: online (charinfo) e, se offline, banco padrao do QBCore.
    getIdentity = function(user_id)
        local id = getOnlineIdentity(user_id)
        if id then return id end
        return getOfflineIdentity(user_id)
    end,

    -- Resolucao offline: license -> citizenid (banco padrao do QBCore:
    -- players.license/license2). Retorna nil se o jogador nao existir.
    resolveUserIdFromIds = function(license, steam)
        if not license then return nil end
        local ok, rows = pcall(function()
            return exports.oxmysql:executeSync(
                "SELECT citizenid FROM players WHERE license IN (?, ?) OR license2 IN (?, ?) LIMIT 1",
                { "license:" .. license, license, "license2:" .. license, license })
        end)
        if ok and rows and rows[1] and rows[1].citizenid then
            return tostring(rows[1].citizenid)
        end
        return nil
    end,

    -- Resolucao offline reversa: citizenid -> identifiers (license).
    getIdentifiersByUserId = function(user_id)
        if not user_id then return nil end
        local ok, rows = pcall(function()
            return exports.oxmysql:executeSync(
                "SELECT license FROM players WHERE citizenid = ? LIMIT 1", { tostring(user_id) })
        end)
        if ok and rows and rows[1] and rows[1].license then
            local lic = tostring(rows[1].license)
            if not lic:find("^license2?:") then lic = "license:" .. lic end
            return { lic }
        end
        return nil
    end,

    -- Eventos de spawn registrados no client (core/modules/runtime/client.lua)
    spawnEvents = { "QBCore:Client:OnPlayerLoaded" },
})

-- ==========================================================================
-- PERMISSOES (FrameworkPermissions)
-- ==========================================================================
FrameworkPermissions.Add(function(source, permission)
    local QBCore = getQBCore()
    if not QBCore or not QBCore.Functions then
        return false
    end

    if type(QBCore.Functions.HasPermission) == "function" then
        local ok, result = pcall(QBCore.Functions.HasPermission, source, permission)

        if ok and result then
            return true
        end
    end

    if type(QBCore.Functions.GetPermission) == "function" then
        local ok, result = pcall(QBCore.Functions.GetPermission, source)

        if ok then
            if FrameworkPermissions.Normalize(result) == permission then
                return true
            end

            if type(result) == "table" then
                for key, value in pairs(result) do
                    if type(key) == "string"
                    and FrameworkPermissions.Normalize(key) == permission
                    and value then
                        return true
                    end

                    if type(value) == "string"
                    and FrameworkPermissions.Normalize(value) == permission then
                        return true
                    end
                end
            end
        end
    end

    if type(QBCore.Functions.GetPlayer) == "function" then
        local ok, Player = pcall(QBCore.Functions.GetPlayer, source)

        if ok and Player and Player.PlayerData then
            if FrameworkPermissions.Normalize(Player.PlayerData.permission) == permission then
                return true
            end

            if Player.PlayerData.job
            and FrameworkPermissions.Normalize(Player.PlayerData.job.name) == permission then
                return true
            end

            if Player.PlayerData.gang
            and FrameworkPermissions.Normalize(Player.PlayerData.gang.name) == permission then
                return true
            end
        end
    end

    return false
end)

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================
