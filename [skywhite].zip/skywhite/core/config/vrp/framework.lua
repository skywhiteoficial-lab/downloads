-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- Instancia compartilhada do Kernel (definida em core/modules/lib/kernel.lua).
local Kernel = _G["SkywhiteKernel"]

-- ==========================================================================
-- ADAPTER vRP
-- --------------------------------------------------------------------------
-- Toda a integracao com o vRP mora aqui: interface (lib/Proxy), identidade
-- (passport), permissao, kick, banco de dados (prepare/execute/query) e os
-- eventos de spawn do client.
-- ==========================================================================

-- Garante o global `module()` (o vRP define o original via lib/Utils.lua);
-- este e um fallback proprio caso ele ainda nao tenha sido carregado.
local function tryLoadVrpUtils()
    local utils = LoadResourceFile("vrp", "lib/Utils.lua")
    if not utils or utils == "" then
        return false
    end

    local chunk = load(utils, "@vrp/lib/Utils.lua")
    if not chunk then
        return false
    end

    local ok = pcall(chunk)
    return ok and type(module) == "function"
end

local function defineFallbackModule()
    if type(module) == "function" then
        return
    end

    local cache = {}

    function module(name, path)
        if path == nil then
            path = name
            name = GetCurrentResourceName()
        end

        local cacheKey = name .. "/" .. path
        if cache[cacheKey] ~= nil then
            return cache[cacheKey]
        end

        local data = LoadResourceFile(name, path .. ".lua")
        if not data or data == "" then
            return nil
        end

        local chunk = load(data, "@" .. name .. "/" .. path .. ".lua")
        if not chunk then
            return nil
        end

        local ok, result = pcall(chunk)
        if not ok then
            print(("^1[SKYWHITE] Falha ao carregar modulo '%s': %s^0"):format(cacheKey, tostring(result)))
            return nil
        end

        cache[cacheKey] = result
        return result
    end
end

-- 1) Prioriza o Utils real do vRP quando disponivel (nao quebra nada no vRP).
tryLoadVrpUtils()

-- 2) Garante um `module` funcional para o getVRPInterface() abaixo.
defineFallbackModule()

local Framework = {}

local vRP_interface = nil

local function getVRPInterface()
    if not vRP_interface then
        local ok, result = pcall(function()
            return module("vrp", "lib/Proxy").getInterface("vRP")
        end)
        if ok and result then
            vRP_interface = result
        end
    end
    return vRP_interface
end

-- Chama o primeiro metodo da lista que responder de verdade (a interface via
-- Proxy resolve QUALQUER nome como funcao, entao validamos pela resposta).
local function callVRP(funcNames, ...)
    local vrp = getVRPInterface()
    if not vrp then
        return nil
    end

    for _, name in ipairs(funcNames) do
        local ok, result = pcall(vrp[name], ...)
        if ok and result ~= nil then
            return result
        end
    end

    return nil
end

-- Cache do metodo que realmente respondeu (aprendido em runtime). Depois de
-- descoberto, so ele e chamado -- elimina o flood de "proxy call X not found"
-- causado por escanear a lista inteira sempre.
local resolvedIdMethod = nil

-- Cache por source, alimentado tambem pelo evento de spawn (abaixo). Evita
-- qualquer chamada via proxy quando ja sabemos o passport do jogador.
local sourcePassportCache = {}

function Framework.getUserId(source)
    if sourcePassportCache[source] then
        return sourcePassportCache[source]
    end

    local names = resolvedIdMethod and { resolvedIdMethod }
        or { "getUserId", "Passport", "userId", "GetUserId", "getPlayerId", "User_id", "user_id", "getId", "GetId", "getUserIdentifier" }

    for _, name in ipairs(names) do
        local vrp = getVRPInterface()
        if vrp then
            local ok, passport = pcall(vrp[name], source)
            if ok and passport then
                resolvedIdMethod = name
                sourcePassportCache[source] = passport
                return passport
            end
        end
    end

    return nil
end

function Framework.hasPermission(user_id, perm)
    return callVRP({ "HasPermission", "hasPermission", "CheckPermission", "checkPermission" }, user_id, perm) or false
end

function Framework.getUserSource(user_id)
    local vrp = getVRPInterface()
    if vrp then
        if vrp.getUserSource then
            return vrp.getUserSource(user_id)
        elseif vrp.Source then
            return vrp.Source(user_id)
        else
            print("^1[Framework] Erro: Funcao 'getUserSource' ou 'Source' nao encontrada no vRP.^0")
            return nil
        end
    else
        print("^1[Framework] Erro: vRP nao ativo para obter user source.^0")
        return nil
    end
end

function Framework.kick(source, reason)
    local vrp = getVRPInterface()

    if vrp and vrp.Kick then
        return vrp.Kick(source, reason)
    end

    -- fallback
    if DropPlayer then
        return DropPlayer(source, reason)
    end
end

function Framework.prepare(name, query)
    local vrp = getVRPInterface()

    if vrp then
        if vrp.prepare then
            vrp.prepare(name, query)
        elseif vrp.Prepare then
            vrp.Prepare(name, query)
        end
    end
end

function Framework.execute(name, params)
    local vrp = getVRPInterface()
    if vrp then
        if vrp.execute then
            return vrp.execute(name, params or {})
        elseif vrp.Query then
            return vrp.Query(name, params or {})
        else
            print("^1[Framework] Erro: Funcao 'execute' ou 'Query' nao encontrada no vRP para query: " .. name .. "^0")
            return false
        end
    else
        print("^1[Framework] Erro: vRP nao ativo para executar query: " .. name .. "^0")
        return false
    end
end

function Framework.query(name, params)
    local vrp = getVRPInterface()
    if vrp then
        if vrp.query then
            return vrp.query(name, params or {})
        elseif vrp.Query then
            return vrp.Query(name, params or {})
        else
            print("^1[Framework] Erro: Funcao 'query' ou 'Query' nao encontrada no vRP para query: " .. name .. "^0")
            return {}
        end
    else
        print("^1[Framework] Erro: vRP nao ativo para consultar query: " .. name .. "^0")
        return {}
    end
end

AddEventHandler("playerDropped", function()
    local src = source
    if src then sourcePassportCache[src] = nil end
end)

-- ==========================================================================
-- PERMISSOES (FrameworkPermissions)
-- ==========================================================================
local PermissionMethods = { "HasPermission", "hasPermission", "CheckPermission", "checkPermission" }
local GroupMethods = { "HasGroup", "hasGroup", "CheckGroup", "checkGroup" }
local ServiceMethods = { "HasService", "hasService", "CheckService", "checkService" }

local function PermissionVariants(permission)
    if type(permission) ~= "string" or permission == "" then
        return { permission }
    end

    local titleCase = permission:sub(1, 1):upper() .. permission:sub(2)
    local upperCase = permission:upper()
    local variants = { permission }

    if titleCase ~= permission then
        variants[#variants + 1] = titleCase
    end
    if upperCase ~= permission and upperCase ~= titleCase then
        variants[#variants + 1] = upperCase
    end

    return variants
end

local function CheckMethods(methods, identifier, permission)
    local variants = PermissionVariants(permission)
    local vrp = getVRPInterface()
    if not vrp then
        return false
    end

    for v = 1, #variants do
        for i = 1, #methods do
            local ok, result = pcall(vrp[methods[i]], identifier, variants[v])

            if ok and result then
                return true
            end
        end
    end

    return false
end

FrameworkPermissions.Add(function(source, permission)
    if not getVRPInterface() or not source or not permission then
        return false
    end

    local passport = Framework.getUserId(source)

    if not passport then
        return false
    end

    if CheckMethods(PermissionMethods, passport, permission) then
        return true
    end

    if CheckMethods(GroupMethods, passport, permission) then
        return true
    end

    if CheckMethods(ServiceMethods, passport, permission) then
        return true
    end

    return false
end)

-- ==========================================================================
-- PROVIDER vRP (hooks do skywhite)
-- ==========================================================================
Kernel.register("vrp", {
    -- Interface vRP disponivel?
    isActive = function()
        return getVRPInterface() ~= nil
    end,

    -- user_id = passport (INT)
    getUserId = function(source)
        return Framework.getUserId(source)
    end,

    -- source a partir do passport
    getUserSource = function(user_id)
        return Framework.getUserSource(user_id)
    end,

    -- Identidade (getUserIdentity / Identity / getUserIdentity)
    getIdentity = function(user_id)
        local vrp = getVRPInterface()
        if not vrp then
            return nil
        end

        -- vRP classico devolve name/firstname; Creative devolve Name/Lastname.
        for _, name in ipairs({ "getUserIdentity", "GetUserIdentity", "getIdentity", "Identity" }) do
            local ok, res = pcall(vrp[name], user_id)
            if ok and type(res) == "table" and (res.name or res.Name or res.nome) then
                return { name = res.Name or res.name or res.nome,
                         firstname = res.Lastname or res.lastname or res.sobrenome or res.name2 }
            end
        end

        -- Fallback: FullName (string "Nome Sobrenome")
        for _, name in ipairs({ "FullName", "getName" }) do
            local ok, res = pcall(vrp[name], user_id)
            if ok and type(res) == "string" and res ~= "" then
                local a, b = res:match("^(%S+)%s+(%S+)$")
                if a then return { name = a, firstname = b } end
                return { name = res }
            end
        end

        return nil
    end,

    -- Permissao direto no vRP
    hasPermission = function(user_id, perm)
        return Framework.hasPermission(user_id, perm)
    end,

    -- Kick proprio do vRP (comando de punicao do servidor)
    kick = function(source, reason)
        return Framework.kick(source, reason)
    end,

    -- Banco de dados: roteia pelas queries registradas no vRP.
    prepare = function(name, query)
        Framework.prepare(name, query)
    end,

    execute = function(name, params)
        return Framework.execute(name, params) or false
    end,

    query = function(name, params)
        return Framework.query(name, params)
    end,

    -- Resolucao offline (jogador fora do servidor): license/steam -> passport.
    -- Usa a tabela vrp_user_ids (tabela padrao de identidade do proprio vRP).
    resolveUserIdFromIds = function(license, steam)
        if not license and not steam then return nil end
        local conditions = {}
        local params = {}
        if license then
            table.insert(conditions, "identifier = ?")
            table.insert(params, "license:" .. license)
        end
        if steam then
            table.insert(conditions, "identifier = ?")
            table.insert(params, "steam:" .. steam)
        end
        local ok, rows = pcall(function()
            return exports.oxmysql:executeSync(
                "SELECT user_id FROM vrp_user_ids WHERE " .. table.concat(conditions, " OR ") .. " LIMIT 1",
                params)
        end)
        if ok and rows and rows[1] and rows[1].user_id then
            return rows[1].user_id
        end
        return nil
    end,

    -- Resolucao offline reversa: passport -> identifiers conhecidos.
    getIdentifiersByUserId = function(user_id)
        local ok, rows = pcall(function()
            return exports.oxmysql:executeSync(
                "SELECT identifier FROM vrp_user_ids WHERE user_id = ?", { user_id })
        end)
        if ok and type(rows) == "table" then
            local out = {}
            for _, row in ipairs(rows) do
                if row.identifier and row.identifier ~= "" then
                    out[#out + 1] = row.identifier
                end
            end
            if #out > 0 then return out end
        end
        return nil
    end,

    -- Eventos de spawn registrados no client (core/modules/runtime/client.lua)
    spawnEvents = { "vRP:playerSpawn" },
})

-- O proprio evento de spawn ja entrega o user_id -- preenche o cache direto,
-- sem precisar de nenhuma chamada via proxy pra esse jogador.
AddEventHandler("vRP:playerSpawn", function(user_id)
    local src = source
    if src and user_id then
        sourcePassportCache[src] = user_id
    end
end)

-- ==========================================================================
-- TABELA vrp_user_ids (resolucao offline)
-- ==========================================================================
Citizen.CreateThread(function()
    local state = GetResourceState("vrp")
    if state == "missing" or state == "unknown" then
        return
    end
    Citizen.Wait(3000)

    local okC, rowsC = pcall(function()
        return exports.oxmysql:executeSync("SHOW TABLES LIKE 'vrp_user_ids'", {})
    end)
    if okC and rowsC and #rowsC == 0 then
        pcall(function()
            exports.oxmysql:executeSync([[
                CREATE TABLE IF NOT EXISTS vrp_user_ids (
                    identifier VARCHAR(100) NOT NULL,
                    user_id INT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (identifier),
                    INDEX idx_user_id (user_id)
                )
            ]], {})
        end)
        print("^2[Kernel/vrp] Tabela vrp_user_ids criada (resolucao offline de user_id).^0")
    end
end)

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================