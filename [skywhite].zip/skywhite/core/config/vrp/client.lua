-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- ==========================================================================
-- ADAPTER CLIENT vRP
-- --------------------------------------------------------------------------
-- Traduz as notificacoes do skywhite ("skywhite:notify") para a notificacao
-- nativa do vRP ("Notify"), mesmo formato usado antes pela integracao vRP:
--   TriggerEvent("Notify", tipo, mensagem, duracaoSegundos)
-- ==========================================================================
KernelClient.register("vrp", function(kind, message, duration)
    TriggerEvent("Notify", kind, tostring(message), duration)
end)