-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- ==========================================================================
-- ADAPTER CLIENT ESX
-- --------------------------------------------------------------------------
-- Traduz as notificacoes do skywhite ("skywhite:notify") para a notificacao
-- nativa do ESX:
--   1) exports['es_extended']:Notify(mensagem, tipo, duracaoMs) (esx_legacy);
--   2) fallback no evento "esx:showNotification" (versoes antigas).
-- ==========================================================================
KernelClient.register("esx", function(kind, message, duration)
    message = tostring(message)

    local okEx = pcall(function()
        local ESX = exports and exports['es_extended']
        if ESX and type(ESX.Notify) == "function" then
            local ms = duration and (tonumber(duration) * 1000) or nil
            ESX.Notify(message, kind, ms)
            return
        end
        TriggerEvent("esx:showNotification", message)
    end)

    if not okEx then
        TriggerEvent("esx:showNotification", message)
    end
end)