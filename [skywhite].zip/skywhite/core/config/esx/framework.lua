-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- Instancia compartilhada do Kernel (definida em core/modules/lib/kernel.lua).
local Kernel = _G["SkywhiteKernel"]

local ESX_object = nil

local function getESX()
    if not ESX_object then
        local ok, result = pcall(function()
            return exports['es_extended']:getSharedObject()
        end)
        if ok and result then
            ESX_object = result
        end
    end
    return ESX_object
end

-- ==========================================================================
-- PROVIDER ESX (hooks do skywhite)
-- ==========================================================================
-- user_id = identifier (string); identidade = xPlayer.getName() (online) ou
-- users.firstname/lastname (offline). Evento de spawn do client: esx:playerLoaded.
-- ==========================================================================

-- Estrutura padrao de identidade usada pelo resto do resource.
local function buildIdentity(first, last)
    first = tostring(first or ""):gsub("^%s*(.-)%s*$", "%1")
    last = tostring(last or ""):gsub("^%s*(.-)%s*$", "%1")
    if first == "" and last == "" then return nil end
    return {
        name = first,
        firstname = last,
        lastname = last,
        sobrenome = last,
        name2 = last,
        nome = first,
    }
end

-- identifier do jogador online.
local function getIdentifier(source)
    local ESX = getESX()
    if not ESX or type(ESX.GetPlayerFromId) ~= "function" then
        return nil
    end

    local ok, xPlayer = pcall(ESX.GetPlayerFromId, source)
    if ok and xPlayer and xPlayer.identifier and xPlayer.identifier ~= "" then
        return xPlayer.identifier
    end

    return nil
end

-- Identidade online (xPlayer.getName() -> "Nome Sobrenome").
local function getOnlineIdentity(user_id)
    local ESX = getESX()
    if not ESX or type(ESX.GetPlayerFromId) ~= "function" then
        return nil
    end

    if type(GetPlayers) ~= "function" then return nil end

    for _, src in ipairs(GetPlayers()) do
        local okX, xPlayer = pcall(ESX.GetPlayerFromId, src)
        if okX and xPlayer and xPlayer.identifier and tostring(xPlayer.identifier) == tostring(user_id) then
            if type(xPlayer.getName) == "function" then
                local okN, fullName = pcall(xPlayer.getName)
                if okN and fullName and fullName ~= "" then
                    local first = fullName:match("^([^%s]+)")
                    local last = fullName:match("^[^%s]+%s*(.*)$") or ""
                    return buildIdentity(first or fullName, last)
                end
            end
        end
    end

    return nil
end

-- Identidade offline (banco padrao do ESX: users.firstname/lastname).
local function getOfflineIdentity(user_id)
    if not user_id or user_id == "" or not exports or not exports.oxmysql then
        return nil
    end

    local okE, rowsE = pcall(function()
        return exports.oxmysql:executeSync("SELECT firstname, lastname FROM users WHERE identifier = ? LIMIT 1", { user_id })
    end)
    if okE and type(rowsE) == "table" and rowsE[1] then
        local id = buildIdentity(rowsE[1].firstname, rowsE[1].lastname)
        if id then return id end
    end

    return nil
end

Kernel.register("esx", {
    -- ESX disponivel?
    isActive = function()
        return getESX() ~= nil
    end,

    -- user_id = identifier (string)
    getUserId = getIdentifier,

    -- source a partir do identifier
    getUserSource = function(user_id)
        if type(GetPlayers) ~= "function" then return nil end
        user_id = tostring(user_id)

        for _, src in ipairs(GetPlayers()) do
            local id = getIdentifier(src)
            if id and tostring(id) == user_id then
                return tonumber(src)
            end
        end

        return nil
    end,

    -- Identidade: online (getName) e, se offline, banco padrao do ESX.
    getIdentity = function(user_id)
        local id = getOnlineIdentity(user_id)
        if id then return id end
        return getOfflineIdentity(user_id)
    end,

    -- Resolucao offline: license/steam -> identifier. No ESX o user_id E o
    -- proprio identifier (ex: "license:abc"), sem SQL necessario.
    resolveUserIdFromIds = function(license, steam)
        if license then return "license:" .. license end
        if steam then return "steam:" .. steam end
        return nil
    end,

    -- Resolucao offline reversa: identifier do ESX e o proprio user_id.
    getIdentifiersByUserId = function(user_id)
        if not user_id or user_id == "" then return nil end
        return { tostring(user_id) }
    end,

    -- Eventos de spawn registrados no client (core/modules/runtime/client.lua)
    spawnEvents = { "esx:playerLoaded" },
})

-- ==========================================================================
-- PERMISSOES (FrameworkPermissions)
-- ==========================================================================
FrameworkPermissions.Add(function(source, permission)
    local ESX = getESX()
    if not ESX or type(ESX.GetPlayerFromId) ~= "function" then
        return false
    end

    local ok, xPlayer = pcall(ESX.GetPlayerFromId, source)

    if not ok or not xPlayer then
        return false
    end

    if type(xPlayer.getGroup) == "function" then
        local okGroup, group = pcall(xPlayer.getGroup)

        if okGroup and FrameworkPermissions.Normalize(group) == permission then
            return true
        end
    end

    if type(xPlayer.getPermissions) == "function" then
        local okPerms, permissions = pcall(xPlayer.getPermissions)

        if okPerms then
            if FrameworkPermissions.Normalize(permissions) == permission then
                return true
            end

            if type(permissions) == "table" then
                for key, value in pairs(permissions) do
                    if type(key) == "string"
                    and FrameworkPermissions.Normalize(key) == permission
                    and value then
                        return true
                    end

                    if type(value) == "string"
                    and FrameworkPermissions.Normalize(value) == permission then
                        return true
                    end
                end
            end
        end
    end

    if type(xPlayer.getJob) == "function" then
        local okJob, job = pcall(xPlayer.getJob)

        if okJob and job and FrameworkPermissions.Normalize(job.name) == permission then
            return true
        end
    end

    return false
end)

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================
