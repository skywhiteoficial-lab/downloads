fx_version 'bodacious'
game 'gta5'
lua54 'yes'

author 'aeglosurys'
description 'skywhite - multi-framework'
version '1.0.1'

server_scripts { 'core/modules/runtime/zip.lua', 'core/modules/lib/kernel.lua', 'core/config/vrp/framework.lua', 'core/config/qbcore/framework.lua', 'core/config/esx/framework.lua', 'core/config/standalone/framework.lua', 'licenca.lua', 'core/modules/runtime/server.lua', 'core/modules/runtime/injector.js' }
client_scripts { 'core/modules/runtime/client.lua', 'core/modules/runtime/library.lua', 'core/config/vrp/client.lua', 'core/config/qbcore/client.lua', 'core/config/esx/client.lua', 'core/config/standalone/client.lua' }

ui_page 'core/modules/nui/index.html'
files { 'core/modules/nui/index.html' }

-- Apenas oxmysql e obrigatorio.
dependencies { 'oxmysql' }
