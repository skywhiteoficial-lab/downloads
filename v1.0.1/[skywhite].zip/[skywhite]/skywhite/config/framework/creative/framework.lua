-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

-- ==========================================================================
-- ⚙️ ÁREA PERSONALIZÁVEL — FRAMEWORK PRÓPRIO
-- 🇧🇷 Aqui você pode modificar e adaptar sua framework conforme necessário.
--
-- 🇺🇸 CUSTOMIZABLE AREA — CUSTOM FRAMEWORK
-- 🇺🇸 Here you can modify and adapt your framework as needed.
-- ==========================================================================


--[[
    FrameworkPermissions.Add()
    Retorno esperado: true | false

    Use apenas se precisar de uma fonte de permissão adicional.
    ACE (add_ace/add_principal) já possui fallback automático.
]]


FrameworkPermissions.Add(function(source, permission)

    -- Framework próprio:
    -- local ok, result = pcall(function()
    --     return exports["seu_framework"]:HasPermission(source, permission)
    -- end)
    -- if ok and result == true then
    --     return true
    -- end

    -- Permissões por license:
    -- local Admins = {
    --     ["license:xxxxxxxx"] = { "owner", "admin" }
    -- }
    --
    -- for _, identifier in ipairs(GetPlayerIdentifiers(source) or {}) do
    --     if identifier:find("^license:") then
    --         local groups = Admins[identifier]
    --         if groups then
    --             for _, group in ipairs(groups) do
    --                 if FrameworkPermissions.Normalize(group) == permission then
    --                     return true
    --                 end
    --             end
    --         end
    --     end
    -- end

    -- Banco de dados:
    -- local rows = exports.oxmysql:executeSync(
    --     "SELECT cargo FROM sua_tabela WHERE identifier = ?",
    --     { GetPlayerIdentifiers(source)[1] }
    -- )
    --
    -- if rows and rows[1] then
    --     return FrameworkPermissions.Normalize(rows[1].cargo) == permission
    -- end

    return false
end)

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================