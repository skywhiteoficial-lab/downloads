-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

FrameworkPermissions = {}

local Methods = {}

local AdminGroups = {

}

local AdminGroups = {
    "owner", "dono", "admin", "god", "mod", "deus", "founder", "fundador", "coowner", "co-owner", "socio", "sócio", "diretor", "director", "direcao", "direção",
    "admin", "administrator", "administrador", "adminmaster", "masteradmin", "superadmin", "superadministrator",
    "superadministrador", "headadmin", "leadadmin", "senioradmin", "adminmanager", "manager", "gerente", "gestor", "management",
    "gerência", "coordenador", "coordenator", "coordinator", "supervisor", "moderator", "moderador", "moderation", "moderacao",
    "moderação", "seniormod", "headmod", "leadmod", "mod", "trialmod", "support", "suporte", "helper", "ajudante", "helps",
    "atendente", "suportejr", "suportesr", "staff", "staffteam", "adminteam", "team", "equipe", "equipeadm", "staffmanager",
    "dev", "developer", "desenvolvedor", "developerteam", "sysadmin", "sysop", "ownerteam", "communitymanager", "community", 
    "trialstaff", "trialadmin", "traineestaff", "trainee", "estagiario", "estagiário", "communitystaff", "gerencia"
}

function FrameworkPermissions.Normalize(text)
    if type(text) ~= "string" then
        return text
    end

    return text:gsub("^%s+", ""):gsub("%s+$", ""):lower()
end

local function isCleanIdentifier(text)
    if type(text) ~= "string" then return false end
    if text == "" or #text > 64 then return false end
    return text:match("^[%w%._%-áàâãéêíóôõúüçÁÀÂÃÉÊÍÓÔÕÚÜÇ ]+$") ~= nil
end

function FrameworkPermissions.Add(callback)
    if type(callback) ~= "function" then
        return false
    end

    Methods[#Methods + 1] = callback
    return true
end

function FrameworkPermissions.Remove(callback)
    if type(callback) ~= "function" then
        return false
    end

    for i = #Methods, 1, -1 do
        if Methods[i] == callback then
            table.remove(Methods, i)
            return true
        end
    end

    return false
end

function FrameworkPermissions.Clear()
    Methods = {}
end

function FrameworkPermissions.Count()
    return #Methods
end

function FrameworkPermissions.GetMethods()
    local copy = {}
    for i = 1, #Methods do
        copy[i] = Methods[i]
    end
    return copy
end


function FrameworkPermissions.HasPermission(source, permission)
    source = tonumber(source)

    if not source or source <= 0 then
        return false
    end

    if type(GetPlayerName) == "function" then
        local ok, name = pcall(GetPlayerName, source)
        if not ok or not name or name == "" then
            return false
        end
    end

    if not isCleanIdentifier(permission) then
        return false
    end

    permission = FrameworkPermissions.Normalize(permission)

    for i = 1, #Methods do
        local ok, result = pcall(Methods[i], source, permission)

        if ok and result == true then
            return true
        end
    end

    if type(IsPlayerAceAllowed) == "function" then
        local ok, result = pcall(IsPlayerAceAllowed, source, permission)

        if ok and result then
            return true
        end

        ok, result = pcall(IsPlayerAceAllowed, source, "group." .. permission)

        if ok and result then
            return true
        end
    end

    return false
end

function FrameworkPermissions.AddAdminGroup(name)
    if not isCleanIdentifier(name) then
        return false
    end

    name = FrameworkPermissions.Normalize(name)

    for i = 1, #AdminGroups do
        if AdminGroups[i] == name then
            return false
        end
    end

    AdminGroups[#AdminGroups + 1] = name
    return true
end

function FrameworkPermissions.GetAdminGroups()
    local copy = {}
    for i = 1, #AdminGroups do
        copy[i] = AdminGroups[i]
    end
    return copy
end

function FrameworkPermissions.IsAdmin(source)
    for i = 1, #AdminGroups do
        if FrameworkPermissions.HasPermission(source, AdminGroups[i]) then
            return true
        end
    end

    return false
end

FrameworkPermissions.Check = FrameworkPermissions.HasPermission
FrameworkPermissions.IsAdministrator = FrameworkPermissions.IsAdmin
FrameworkPermissions.EhAdmin = FrameworkPermissions.IsAdmin

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================