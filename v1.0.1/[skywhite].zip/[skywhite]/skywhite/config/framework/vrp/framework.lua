-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

local PassportMethods = {
    "Passport", "GetPassport", "getPassport",
    "UserId", "userId", "GetUserId", "getUserId"
}

local PermissionMethods = { "HasPermission", "hasPermission", "CheckPermission", "checkPermission" }
local GroupMethods = { "HasGroup", "hasGroup", "CheckGroup", "checkGroup" }
local ServiceMethods = { "HasService", "hasService", "CheckService", "checkService" }

local vRP_interface = nil

local function getVRP()
    if not vRP_interface then
        local ok, result = pcall(function()
            return module("vrp", "lib/Proxy").getInterface("vRP")
        end)
        if ok and result then
            vRP_interface = result
        end
    end
    return vRP_interface
end

local function CallVRP(method, ...)
    local vRP = getVRP()
    if not vRP or type(vRP[method]) ~= "function" then
        return false, nil
    end

    local ok, result = pcall(vRP[method], ...)
    return ok, ok and result or nil
end

local function GetPassport(source)
    for i = 1, #PassportMethods do
        local ok, passport = CallVRP(PassportMethods[i], source)

        if ok and passport then
            return passport
        end
    end

    return nil
end

local function PermissionVariants(permission)
    if type(permission) ~= "string" or permission == "" then
        return { permission }
    end

    local titleCase = permission:sub(1, 1):upper() .. permission:sub(2)
    local upperCase = permission:upper()
    local variants = { permission }

    if titleCase ~= permission then
        variants[#variants + 1] = titleCase
    end
    if upperCase ~= permission and upperCase ~= titleCase then
        variants[#variants + 1] = upperCase
    end

    return variants
end

local function CheckMethods(methods, identifier, permission)
    local variants = PermissionVariants(permission)

    for v = 1, #variants do
        for i = 1, #methods do
            local ok, result = CallVRP(methods[i], identifier, variants[v])

            if ok and result then
                return true
            end
        end
    end

    return false
end

FrameworkPermissions.Add(function(source, permission)
    if not getVRP() or not source or not permission then
        return false
    end

    local passport = GetPassport(source)

    if not passport then
        return false
    end

    if CheckMethods(PermissionMethods, passport, permission) then
        return true
    end

    if CheckMethods(GroupMethods, passport, permission) then
        return true
    end

    if CheckMethods(ServiceMethods, passport, permission) then
        return true
    end

    return false
end)

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================