-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

local ESX_object = nil

local function getESX()
    if not ESX_object then
        local ok, result = pcall(function()
            return exports['es_extended']:getSharedObject()
        end)
        if ok and result then
            ESX_object = result
        end
    end
    return ESX_object
end

FrameworkPermissions.Add(function(source, permission)
    local ESX = getESX()
    if not ESX or type(ESX.GetPlayerFromId) ~= "function" then
        return false
    end

    local ok, xPlayer = pcall(ESX.GetPlayerFromId, source)

    if not ok or not xPlayer then
        return false
    end

    if type(xPlayer.getGroup) == "function" then
        local okGroup, group = pcall(xPlayer.getGroup)

        if okGroup and FrameworkPermissions.Normalize(group) == permission then
            return true
        end
    end

    if type(xPlayer.getPermissions) == "function" then
        local okPerms, permissions = pcall(xPlayer.getPermissions)

        if okPerms then
            if FrameworkPermissions.Normalize(permissions) == permission then
                return true
            end

            if type(permissions) == "table" then
                for key, value in pairs(permissions) do
                    if type(key) == "string"
                    and FrameworkPermissions.Normalize(key) == permission
                    and value then
                        return true
                    end

                    if type(value) == "string"
                    and FrameworkPermissions.Normalize(value) == permission then
                        return true
                    end
                end
            end
        end
    end

    if type(xPlayer.getJob) == "function" then
        local okJob, job = pcall(xPlayer.getJob)

        if okJob and job and FrameworkPermissions.Normalize(job.name) == permission then
            return true
        end
    end

    return false
end)

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================