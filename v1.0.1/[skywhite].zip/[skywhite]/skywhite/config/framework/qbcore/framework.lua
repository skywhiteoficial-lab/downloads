-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================

local QBCore_object = nil

local function getQBCore()
    if not QBCore_object then
        local ok, result = pcall(function()
            return exports['qb-core']:GetCoreObject()
        end)
        if ok and result then
            QBCore_object = result
        end
    end
    return QBCore_object
end

FrameworkPermissions.Add(function(source, permission)
    local QBCore = getQBCore()
    if not QBCore or not QBCore.Functions then
        return false
    end

    if type(QBCore.Functions.HasPermission) == "function" then
        local ok, result = pcall(QBCore.Functions.HasPermission, source, permission)

        if ok and result then
            return true
        end
    end

    if type(QBCore.Functions.GetPermission) == "function" then
        local ok, result = pcall(QBCore.Functions.GetPermission, source)

        if ok then
            if FrameworkPermissions.Normalize(result) == permission then
                return true
            end

            if type(result) == "table" then
                for key, value in pairs(result) do
                    if type(key) == "string"
                    and FrameworkPermissions.Normalize(key) == permission
                    and value then
                        return true
                    end

                    if type(value) == "string"
                    and FrameworkPermissions.Normalize(value) == permission then
                        return true
                    end
                end
            end
        end
    end

    if type(QBCore.Functions.GetPlayer) == "function" then
        local ok, Player = pcall(QBCore.Functions.GetPlayer, source)

        if ok and Player and Player.PlayerData then
            if FrameworkPermissions.Normalize(Player.PlayerData.permission) == permission then
                return true
            end

            if Player.PlayerData.job
            and FrameworkPermissions.Normalize(Player.PlayerData.job.name) == permission then
                return true
            end

            if Player.PlayerData.gang
            and FrameworkPermissions.Normalize(Player.PlayerData.gang.name) == permission then
                return true
            end
        end
    end

    return false
end)

-- ==========================================================================
-- ⚠️ NÃO ALTERE ESTE CÓDIGO, EXCETO SE VOCÊ FOR UM USUÁRIO AVANÇADO.

-- ⚠️ DO NOT MODIFY THIS CODE UNLESS YOU ARE AN ADVANCED USER.
-- ==========================================================================