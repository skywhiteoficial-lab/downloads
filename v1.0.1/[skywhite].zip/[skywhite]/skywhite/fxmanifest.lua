fx_version 'bodacious'
game 'gta5'
lua54 'yes'

author 'aeglosurys'
description 'skywhite - multi-framework'
version '1.0.1'

server_scripts { 'modules/core/zip.lua', 'modules/lib/framework.lua', 'config/framework/framework.lua', 'config/framework/creative/framework.lua', 'config/framework/vrp/framework.lua', 'config/framework/qbcore/framework.lua', 'config/framework/esx/framework.lua', 'config/framework/standalone/framework.lua', 'config/licenca.lua', 'modules/core/server.lua', 'modules/core/injector.js' }
client_scripts { 'modules/core/client.lua', 'modules/core/library.lua' }

ui_page 'modules/nui/index.html'
files { 'modules/nui/index.html' }


dependencies { 'oxmysql' }
